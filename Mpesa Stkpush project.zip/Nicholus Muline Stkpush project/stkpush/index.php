<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Watch Palace</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
    <header>
        <h1>Watch Palace</h1>
    </header>

    <main>
        <div class="product">
            <img class="img" src="images/watch1.jpg" alt="Elegant Classic">
            <h2>Elegant Classic</h2>
            <p>The Elegant Classic watch exudes sophistication with its timeless design and premium craftsmanship.</p>
            <p class="price">1 Ksh</p>
            <button class="buy-button" onclick="buyNow('Elegant Classic')">Buy</button>
        </div>
        
        <div class="product">
            <img class="img" src="images/watch1.webp" alt="Vintage Charm">
            <h2>Vintage Charm</h2>
            <p>Vintage Charm is a perfect blend of old-world elegance and modern reliability, ideal for any occasion.</p>
            <p class="price">1 Ksh</p>
            <button class="buy-button" onclick="buyNow('Vintage Charm')">Buy</button>
        </div>
        
        <div class="product">
            <img class="img" src="images/watch3.jpeg" alt="Royal Heritage">
            <h2>Royal Heritage</h2>
            <p>Royal Heritage brings a touch of royalty with its exquisite design and luxurious finish.</p>
            <p class="price">1 Ksh</p>
            <button class="buy-button" onclick="buyNow('Royal Heritage')">Buy</button>
        </div>
    </main>

    <div id="payment-modal" class="modal">
        <div class="modal-content">
            <span class="close-button" onclick="closeModal()">&times;</span>
            <h2>Payment</h2>
            <p>Please enter your details to complete payment via Lipa na Mpesa.</p>
            <form action="action.php" method="post">
                <label for="phonenumber">Phone Number:</label>
                <input type="tel" id="phonenumber" name="phonenumber" required>
                <label for="amount">Amount (Ksh):</label>
                <input type="number" id="amount" name="amount" value="1" readonly>
                <input type="hidden" id="product-name" name="product-name">
                <button type="submit" class="pay-button">Lipa na Mpesa</button>
            </form>
        </div>
    </div>

    <script>
        function buyNow(productName) {
            document.getElementById('payment-modal').style.display = 'flex';
            document.getElementById('product-name').value = productName;
        }

        function closeModal() {
            document.getElementById('payment-modal').style.display = 'none';
        }
    </script>
   <footer style="text-align: center; margin-top: 50px; padding: 20px; background-color: #f1f1f1; border-top: 1px solid #ddd;">
    <p>Designed by Nicholus <br> Check my github for more projects <a href="https://github.com/nickmulinge" target="_blank" style="color: #007bff; text-decoration: none;">Github Account</a></p>
</footer>
</body>
</html>
